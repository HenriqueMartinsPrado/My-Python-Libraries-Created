from setuptools import setup

setup(name='hmp_basic_matrix_algebra',
      version='1.2',
      description='Basic Matrix Algebra Operations',
      packages=['hmp_basic_matrix_algebra'],
      author='Henrique M. Prado',
      author_email='hmartins.prado@gmail.com',
      zip_safe=False)
