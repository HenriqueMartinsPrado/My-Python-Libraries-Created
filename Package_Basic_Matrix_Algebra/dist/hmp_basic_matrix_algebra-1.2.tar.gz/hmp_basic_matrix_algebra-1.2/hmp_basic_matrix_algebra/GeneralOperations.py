class Operations:
    '''This class is going to get the 2 numbers for all operations like add, subtract, division and multiply'''
    def __init__(self, n1, n2):
        self.n1 = n1
        self.n2 = n2