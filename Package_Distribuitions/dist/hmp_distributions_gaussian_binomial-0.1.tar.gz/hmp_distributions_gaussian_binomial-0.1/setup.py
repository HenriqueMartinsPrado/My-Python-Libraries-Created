from setuptools import setup

setup(name='hmp_distributions_gaussian_binomial',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['hmp_distributions_gaussian_binomial'],
      author='Henrique M. Prado',
      author_email='hmartins.prado@gmail.com',
      zip_safe=False)
